# Strawberry Milk (Windows) — private Tailscale Ollama access

The Android app's editable default is `http://100.91.123.85:11434`. The project context identifies `100.91.123.85` as Strawberry Milk's Tailscale IPv4 address. Verify it still matches `ipconfig` / Tailscale before using it.

## 1. Confirm the model and runtime

Open PowerShell on Strawberry Milk:

```powershell
ollama list
ollama ps
```

Confirm `qwen3.8:27b-q8_0` appears in `ollama list`.

## 2. Bind Ollama to the Tailscale interface

Ollama commonly listens on localhost by default. For this prototype, configure the host to listen on its Tailscale address rather than all network interfaces:

```powershell
setx OLLAMA_HOST "100.91.123.85:11434"
```

Then fully quit Ollama from the Windows system tray and start it again so it inherits the new environment variable. If Ollama runs as a Windows service or under another account, set the environment variable for that service account and restart that service instead.

Do not use `0.0.0.0` unless you have deliberately configured and verified restrictive firewall rules for every interface.

## 3. Restrict Windows Firewall to the tailnet

Run PowerShell as Administrator:

```powershell
New-NetFirewallRule -DisplayName "Ollama from Tailscale only" -Direction Inbound -Action Allow -Protocol TCP -LocalAddress 100.91.123.85 -LocalPort 11434 -RemoteAddress 100.64.0.0/10 -Profile Any
```

For tighter security, replace the tailnet range with the phone's exact Tailscale IPv4 address after checking it in the Tailscale app. Also configure Tailscale ACLs/grants so only the phone can reach Strawberry Milk on TCP 11434. Do not create a router port-forward.

## 4. Verify locally on Strawberry Milk

```powershell
Invoke-RestMethod -Uri "http://100.91.123.85:11434/api/tags" -Method Get
```

The response should list the installed models. If this fails, confirm Ollama restarted with the environment variable and that the Tailscale IP is correct.

## 5. Verify from the phone

1. Connect the phone to the same Tailscale network.
2. In Android Agent, set the server URL to `http://100.91.123.85:11434` (or Strawberry Milk's current MagicDNS name if configured).
3. Send a harmless plan request.

**Security note:** Ollama's native API does not provide application-level authentication by default. Tailnet membership alone is not sufficient protection for a mature product. This prototype uses Tailscale reachability and Windows firewall restrictions; before broader use, put an authenticated gateway in front of Ollama and keep secrets out of the APK and logs.
