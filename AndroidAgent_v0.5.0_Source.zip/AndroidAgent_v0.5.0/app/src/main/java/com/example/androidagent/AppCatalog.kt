package com.example.androidagent

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

class AppCatalog(private val context: Context) {
    fun discover(): List<LaunchableApp> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val pm = context.packageManager
        val matches = if (Build.VERSION.SDK_INT >= 33) pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L)) else {
            @Suppress("DEPRECATION") pm.queryIntentActivities(intent, 0)
        }
        return matches.mapNotNull { info ->
            val ai = info.activityInfo ?: return@mapNotNull null
            if (ai.packageName == context.packageName) null else LaunchableApp(
                info.loadLabel(pm)?.toString()?.ifBlank { ai.packageName } ?: ai.packageName,
                ai.packageName
            )
        }.distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
    }

    fun launch(packageName: String): Result<Unit> {
        if (discover().none { it.packageName == packageName }) return Result.failure(IllegalArgumentException("App is not in the visible launcher catalog."))
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            ?: return Result.failure(IllegalStateException("No launch activity is available."))
        return try { intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(intent); Result.success(Unit) }
        catch (e: Exception) { Result.failure(e) }
    }
}
