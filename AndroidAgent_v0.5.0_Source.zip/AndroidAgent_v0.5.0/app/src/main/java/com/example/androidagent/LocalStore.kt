package com.example.androidagent

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.UUID

class LocalStore(context: Context) : SQLiteOpenHelper(context, "android_agent_v05.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE tasks(id TEXT PRIMARY KEY,title TEXT NOT NULL,detail TEXT NOT NULL,status TEXT NOT NULL,created_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE knowledge(id TEXT PRIMARY KEY,category TEXT NOT NULL,content TEXT NOT NULL,created_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE action_log(id TEXT PRIMARY KEY,task_id TEXT,tool TEXT NOT NULL,status TEXT NOT NULL,detail TEXT NOT NULL,created_at INTEGER NOT NULL)")
        db.execSQL("CREATE UNIQUE INDEX idx_action_task_id ON action_log(task_id) WHERE task_id IS NOT NULL")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun wasExecuted(stepId: String): Boolean {
        readableDatabase.rawQuery("SELECT 1 FROM action_log WHERE task_id=? AND status IN ('COMPLETED','LAUNCH_REQUESTED') LIMIT 1", arrayOf(stepId)).use { return it.moveToFirst() }
    }

    fun execute(step: ProposedStep): ToolResult {
        ActionPolicy.validate(step)?.let { return ToolResult.Failure(it) }
        val db = writableDatabase
        db.beginTransaction()
        try {
            val already = db.rawQuery(
                "SELECT 1 FROM action_log WHERE task_id=? AND status='COMPLETED' LIMIT 1",
                arrayOf(step.id)
            ).use { it.moveToFirst() }
            if (already) return ToolResult.Failure("This step ID has already been executed; duplicate execution was blocked.")
            val result = when (step.tool) {
                "create_task" -> {
                    val title = step.arguments.getValue("title").trim()
                    val values = ContentValues().apply {
                        put("id", UUID.randomUUID().toString()); put("title", title)
                        put("detail", step.arguments.getValue("content")); put("status", "OPEN")
                        put("created_at", System.currentTimeMillis())
                    }
                    db.insertOrThrow("tasks", null, values)
                    ToolResult.Success("Created local task: $title")
                }
                "save_preference", "save_instruction" -> {
                    val category = if (step.tool == "save_preference") "PREFERENCE" else "INSTRUCTION"
                    val values = ContentValues().apply {
                        put("id", UUID.randomUUID().toString()); put("category", category)
                        put("content", step.arguments.getValue("content")); put("created_at", System.currentTimeMillis())
                    }
                    db.insertOrThrow("knowledge", null, values)
                    ToolResult.Success("Saved $category locally.")
                }
                else -> ToolResult.Failure("This tool is handled by the Android integration layer.")
            }
            if (result is ToolResult.Success) {
                val logValues = ContentValues().apply {
                    put("id", UUID.randomUUID().toString()); put("task_id", step.id)
                    put("tool", step.tool); put("status", "COMPLETED")
                    put("detail", result.message.take(500)); put("created_at", System.currentTimeMillis())
                }
                db.insertOrThrow("action_log", null, logValues)
                db.setTransactionSuccessful()
            }
            return result
        } catch (e: Exception) {
            return ToolResult.Failure(e.message ?: "Local operation failed")
        } finally {
            db.endTransaction()
        }
    }

    fun log(step: ProposedStep, status: String, detail: String) {
        val v = ContentValues().apply {
            put("id", UUID.randomUUID().toString()); put("task_id", step.id)
            put("tool", step.tool); put("status", status); put("detail", detail.take(500))
            put("created_at", System.currentTimeMillis())
        }
        writableDatabase.insert("action_log", null, v)
    }

    fun record(tool: String, status: String, detail: String) {
        val v = ContentValues().apply {
            put("id", UUID.randomUUID().toString()); put("tool", tool); put("status", status)
            put("detail", detail.take(500)); put("created_at", System.currentTimeMillis())
        }
        writableDatabase.insert("action_log", null, v)
    }

    fun tasks(): List<String> = buildList {
        readableDatabase.rawQuery("SELECT title,status FROM tasks ORDER BY created_at DESC LIMIT 30", null).use { c ->
            while (c.moveToNext()) add("${c.getString(0)} — ${c.getString(1)}")
        }
    }
    fun logs(): List<String> = buildList {
        readableDatabase.rawQuery("SELECT tool,status,detail FROM action_log ORDER BY created_at DESC LIMIT 30", null).use { c ->
            while (c.moveToNext()) add("${c.getString(0)} · ${c.getString(1)} · ${c.getString(2)}")
        }
    }
}
