package com.example.androidagent

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Opt-in bridge. No background tapping or text collection; actions occur only after a user approval. */
class AgentAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* Intentionally no event-content logging. */ }
    override fun onInterrupt() {}

    fun clickVisibleText(text: String, allowedPackages: Set<String>): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() !in allowedPackages) return false
        val matches = root.findAccessibilityNodeInfosByText(text)
        val target = matches.firstOrNull { it.isVisibleToUser && it.isClickable }
            ?: matches.firstOrNull { it.isVisibleToUser }?.findClickableAncestor()
            ?: return false
        return target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun AccessibilityNodeInfo.findClickableAncestor(): AccessibilityNodeInfo? {
        var node: AccessibilityNodeInfo? = this
        while (node != null) {
            if (node.isClickable) return node
            node = node.parent
        }
        return null
    }

    companion object { @Volatile var active: AgentAccessibilityService? = null }
    override fun onServiceConnected() { super.onServiceConnected(); active = this }
    override fun onDestroy() { if (active === this) active = null; super.onDestroy() }
}
