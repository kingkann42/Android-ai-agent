package com.example.androidagent

/** Provider boundary: the phone-side tools and policy layer do not depend on a model vendor. */
interface AiProvider {
    fun generatePlan(serverUrl: String, modelTag: String, userRequest: String): String
}

class OllamaProvider : AiProvider {
    override fun generatePlan(serverUrl: String, modelTag: String, userRequest: String): String =
        OllamaClient.generatePlan(serverUrl, modelTag, userRequest)
}
