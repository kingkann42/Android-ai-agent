package com.example.androidagent

object ActionPolicy {
    private val schemas = mapOf(
        "create_task" to setOf("title", "content"),
        "save_preference" to setOf("content"),
        "save_instruction" to setOf("content"),
        "open_app" to setOf("package_name")
    )
    private val blocked = setOf("send_message", "delete_file", "make_purchase", "change_security_setting", "install_app", "share_location", "run_shell", "read_credentials")

    fun assess(tool: String): RiskLevel = when {
        tool in blocked -> RiskLevel.BLOCKED
        tool == "open_app" -> RiskLevel.SENSITIVE
        tool in schemas -> RiskLevel.LOW
        else -> RiskLevel.BLOCKED
    }

    fun validate(step: ProposedStep): String? {
        if (step.tool in blocked) return "This action is explicitly blocked in v0.5."
        val expected = schemas[step.tool] ?: return "Tool is not enabled in this version."
        if (step.arguments.keys != expected) return "Arguments do not match the approved tool schema."
        if (step.arguments.values.any { it.length > 2000 }) return "Argument exceeds the 2,000-character limit."
        if (step.arguments.values.any { it.isBlank() }) return "Required action content is missing."
        return null
    }
}
