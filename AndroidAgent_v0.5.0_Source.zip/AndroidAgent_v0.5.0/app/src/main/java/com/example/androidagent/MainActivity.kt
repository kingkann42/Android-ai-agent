package com.example.androidagent

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = LocalStore(this)
        val prefs = getSharedPreferences("agent_settings", MODE_PRIVATE)
        setContent { MaterialTheme { AgentScreen(store, prefs) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AgentScreen(store: LocalStore, prefs: android.content.SharedPreferences) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val catalog = remember(context) { AppCatalog(context) }
    val aiProvider = remember { OllamaProvider() }
    var server by remember { mutableStateOf(prefs.getString("server", "http://100.91.123.85:11434") ?: "http://100.91.123.85:11434") }
    var model by remember { mutableStateOf(prefs.getString("model", "qwen3.8:27b-q8_0") ?: "qwen3.8:27b-q8_0") }
    var allowlistedPackage by remember { mutableStateOf(prefs.getString("allowlist", "") ?: "") }
    var request by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Ready. AI reasoning uses Strawberry Milk over your Tailscale network.") }
    var busy by remember { mutableStateOf(false) }
    var plan by remember { mutableStateOf<AgentPlan?>(null) }
    var apps by remember { mutableStateOf(emptyList<LaunchableApp>()) }
    var appSearch by remember { mutableStateOf("") }
    var appStatus by remember { mutableStateOf("Discover apps to populate the launcher list.") }
    var tasks by remember { mutableStateOf(store.tasks()) }
    var logs by remember { mutableStateOf(store.logs()) }
    var selectedFile by remember { mutableStateOf<android.net.Uri?>(null) }
    var selectedFolder by remember { mutableStateOf<android.net.Uri?>(null) }
    var fileName by remember { mutableStateOf("") }
    var folderContents by remember { mutableStateOf(emptyList<String>()) }
    var fileStatus by remember { mutableStateOf("Select a source file and a destination folder to test safe file copying.") }
    var tapText by remember { mutableStateOf("") }
    var accessibilityStatus by remember { mutableStateOf("Accessibility is optional and off until you enable it in Android Settings.") }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            selectedFile = uri
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            fileName = FileTools.displayName(context.contentResolver, uri)
            fileStatus = "Source selected: $fileName"
        }
    }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            selectedFolder = uri
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
            folderContents = runCatching { FileTools.listTree(context.contentResolver, uri) }.getOrElse { emptyList() }
            fileStatus = "Destination folder selected. ${folderContents.size} immediate entries visible."
        }
    }
    val speechPicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) request = spoken
    }

    fun refreshApps() {
        apps = catalog.discover()
        appStatus = "Found ${apps.size} launchable apps visible to Android."
    }
    fun refreshLogs() { tasks = store.tasks(); logs = store.logs() }
    fun executeStep(step: ProposedStep) {
        if (store.wasExecuted(step.id)) { status = "Duplicate execution blocked for this task step."; return }
        val error = ActionPolicy.validate(step)
        if (error != null) {
            status = error
            plan = plan?.copy(steps = plan!!.steps.map { if (it.id == step.id) it.copy(status = StepStatus.REJECTED) else it })
            return
        }
        val result = when (step.tool) {
            "open_app" -> {
                val pkg = step.arguments["package_name"].orEmpty()
                if (apps.none { it.packageName == pkg }) ToolResult.Failure("The requested app is not in the current visible launcher catalog. Refresh discovery first.")
                else catalog.launch(pkg).fold({ ToolResult.Success("Launch requested for $pkg") }, { ToolResult.Failure(it.message ?: "App launch failed") })
            }
            else -> store.execute(step)
        }
        val success = result is ToolResult.Success
        val message = when (result) { is ToolResult.Success -> result.message; is ToolResult.Failure -> result.message }
        if (step.tool == "open_app") store.log(step, if (success) "LAUNCH_REQUESTED" else "FAILED", message)
        status = message
        plan = plan?.copy(steps = plan!!.steps.map { if (it.id == step.id) it.copy(status = if (success) StepStatus.COMPLETED else StepStatus.FAILED) else it })
        refreshLogs()
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Android Agent  ·  v0.5.0") }) }) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 28.dp)
        ) {
            item {
                Text("Your phone-side AI agent", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Reasoning: Strawberry Milk / Ollama · Execution: this Android device · Root: not used", style = MaterialTheme.typography.bodySmall)
            }
            item { SectionTitle("1 · Ask the agent") }
            item {
                OutlinedTextField(value = request, onValueChange = { request = it }, label = { Text("Type an instruction") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your instruction")
                        }
                        runCatching { speechPicker.launch(intent) }.onFailure { status = "Speech recognition is not available on this device." }
                    }) { Text("Speak") }
                    Button(enabled = !busy && request.isNotBlank(), onClick = {
                        busy = true; status = "Sending a planning request to Strawberry Milk…"; plan = null
                        scope.launch {
                            try {
                                val raw = withContext(Dispatchers.IO) { aiProvider.generatePlan(server, model, request) }
                                plan = PlanParser.parse(raw)
                                status = "Plan received. No proposed action has run. Review and approve each step."
                            } catch (e: Exception) { status = "Planning failed: ${e.message ?: "Unknown error"}" }
                            finally { busy = false }
                        }
                    }) { Text(if (busy) "Planning…" else "Create plan") }
                }
                Text(status, style = MaterialTheme.typography.bodyMedium)
            }
            plan?.let { current ->
                item { Text(current.summary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
                items(current.steps, key = { it.id }) { step ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(step.tool, fontWeight = FontWeight.Bold)
                            Text(step.explanation)
                            Text("Risk: ${step.risk} · Status: ${step.status}", style = MaterialTheme.typography.bodySmall)
                            step.arguments.forEach { (key, value) -> Text("$key: $value", style = MaterialTheme.typography.bodySmall) }
                            if (step.status == StepStatus.AWAITING_APPROVAL) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = { executeStep(step) }) { Text("Approve & run") }
                                    OutlinedButton(onClick = {
                                        plan = current.copy(steps = current.steps.map { if (it.id == step.id) it.copy(status = StepStatus.REJECTED) else it })
                                        store.log(step, "REJECTED", "User rejected proposal")
                                        refreshLogs()
                                    }) { Text("Reject") }
                                }
                            }
                        }
                    }
                }
            }
            item { Divider(); SectionTitle("2 · App discovery and launch") }
            item {
                Text("Only launcher-visible apps are listed. Opening an app from this catalog is a direct Android launch; it does not grant access to the app's private data.", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { refreshApps() }) { Text("Discover apps") }
                    OutlinedTextField(value = appSearch, onValueChange = { appSearch = it }, label = { Text("Filter") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                Text(appStatus, style = MaterialTheme.typography.bodySmall)
            }
            items(apps.filter { it.label.contains(appSearch, true) || it.packageName.contains(appSearch, true) }, key = { it.packageName }) { app ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) { Text(app.label, fontWeight = FontWeight.SemiBold); Text(app.packageName, style = MaterialTheme.typography.bodySmall) }
                        OutlinedButton(onClick = {
                            catalog.launch(app.packageName).fold(
                                { store.record("open_app", "LAUNCH_REQUESTED", app.packageName); appStatus = "Launch requested: ${app.label}" },
                                { store.record("open_app", "FAILED", app.packageName); appStatus = "Launch failed: ${it.message}" }
                            ); refreshLogs()
                        }) { Text("Open") }
                    }
                }
            }
            item { Divider(); SectionTitle("3 · User-selected file access") }
            item {
                Text("The system picker grants access only to the file/folder you select. Android protected app-data folders remain unavailable.", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { filePicker.launch(arrayOf("*/*")) }) { Text("Choose source file") }
                    OutlinedButton(onClick = { folderPicker.launch(null) }) { Text("Choose destination folder") }
                }
                Text("Source: ${selectedFile?.let { fileName } ?: "not selected"}", style = MaterialTheme.typography.bodySmall)
                Text("Destination: ${if (selectedFolder == null) "not selected" else "selected"}", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(value = fileName, onValueChange = { fileName = it }, label = { Text("Destination filename") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Button(enabled = selectedFile != null && selectedFolder != null && fileName.isNotBlank(), onClick = {
                    val src = selectedFile!!; val dest = selectedFolder!!; val name = fileName
                    fileStatus = "Copying and verifying…"
                    scope.launch {
                        try {
                            val result = withContext(Dispatchers.IO) { FileTools.copyAndVerify(context.contentResolver, src, dest, name) }
                            fileStatus = "Verified copy: ${result.name} · ${result.bytes} bytes · SHA-256 ${result.sha256}"
                            store.record("copy_file", "VERIFIED", "${result.name}; ${result.bytes} bytes; ${result.sha256}")
                            folderContents = runCatching { FileTools.listTree(context.contentResolver, dest) }.getOrElse { emptyList() }
                            refreshLogs()
                        } catch (e: Exception) { fileStatus = "Copy failed: ${e.message}"; store.record("copy_file", "FAILED", e.message ?: "Unknown error"); refreshLogs() }
                    }
                }) { Text("Copy and verify") }
                Text(fileStatus, style = MaterialTheme.typography.bodySmall)
                if (folderContents.isNotEmpty()) Text("Folder entries: ${folderContents.take(12).joinToString(", ")}", style = MaterialTheme.typography.bodySmall)
            }
            item { Divider(); SectionTitle("4 · Optional Accessibility bridge") }
            item {
                Text("Accessibility is off by default. Enable it only if you want to test task-scoped UI interaction. The service does not collect event text or run background actions.", style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("Open Accessibility settings") }
                OutlinedTextField(value = allowlistedPackage, onValueChange = { allowlistedPackage = it }, label = { Text("Allowed app package name") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = { prefs.edit().putString("allowlist", allowlistedPackage.trim()).apply(); accessibilityStatus = "Saved one-app allowlist: ${allowlistedPackage.trim()}" }) { Text("Save allowlist") }
                OutlinedTextField(value = tapText, onValueChange = { tapText = it }, label = { Text("Exact visible text to tap") }, modifier = Modifier.fillMaxWidth())
                OutlinedButton(enabled = tapText.isNotBlank() && allowlistedPackage.isNotBlank(), onClick = {
                    val svc = AgentAccessibilityService.active
                    val ok = svc?.clickVisibleText(tapText, setOf(allowlistedPackage.trim())) == true
                    accessibilityStatus = if (ok) "Tap action sent to a matching visible control." else "No matching clickable control, service disabled, or active app not allowlisted."
                    store.record("accessibility_tap", if (ok) "ACTION_SENT" else "BLOCKED_OR_NOT_FOUND", "package=${allowlistedPackage.trim()}")
                    refreshLogs()
                }) { Text("Tap approved visible text") }
                Text(accessibilityStatus, style = MaterialTheme.typography.bodySmall)
            }
            item { Divider(); SectionTitle("5 · Connection and model settings") }
            item {
                OutlinedTextField(value = server, onValueChange = { server = it }, label = { Text("Ollama base URL") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(value = model, onValueChange = { model = it }, label = { Text("Model tag") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Button(onClick = { prefs.edit().putString("server", server.trim()).putString("model", model.trim()).apply(); status = "Settings saved on this phone." }) { Text("Save connection settings") }
                Text("Default endpoint is the previously supplied Tailscale address. Confirm that Strawberry Milk exposes Ollama on port 11434 to the tailnet only. No public port forwarding. This prototype does not add Ollama API authentication.", style = MaterialTheme.typography.bodySmall)
            }
            item { Divider(); SectionTitle("6 · Local task history and audit log") }
            item { OutlinedButton(onClick = { refreshLogs() }) { Text("Refresh history") } }
            item { Text("Tasks", fontWeight = FontWeight.SemiBold) }
            items(tasks) { Text("• $it", style = MaterialTheme.typography.bodySmall) }
            item { Text("Recent actions", fontWeight = FontWeight.SemiBold) }
            items(logs) { Text("• $it", style = MaterialTheme.typography.bodySmall) }
            item {
                Divider()
                Text("Prototype boundaries: no root, no shell execution, no SMS/calls/purchases/deletion, no private app-data access, no automatic background listening. Model output is untrusted and must pass local schema validation and user approval.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
}
