package com.example.androidagent

import java.util.UUID

data class ProposedStep(
    val id: String = UUID.randomUUID().toString(),
    val tool: String,
    val arguments: Map<String, String>,
    val explanation: String,
    val risk: RiskLevel,
    val status: StepStatus = StepStatus.AWAITING_APPROVAL
)

enum class RiskLevel { LOW, SENSITIVE, BLOCKED }
enum class StepStatus { AWAITING_APPROVAL, COMPLETED, REJECTED, FAILED }
data class AgentPlan(val summary: String, val steps: List<ProposedStep>)
sealed class ToolResult {
    data class Success(val message: String) : ToolResult()
    data class Failure(val message: String) : ToolResult()
}

data class LaunchableApp(val label: String, val packageName: String)
