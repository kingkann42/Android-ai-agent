package com.example.androidagent

import android.content.ContentResolver
import android.net.Uri
import android.provider.DocumentsContract
import android.database.Cursor
import java.security.MessageDigest

object FileTools {
    data class CopyResult(val name: String, val bytes: Long, val sha256: String)

    fun displayName(resolver: ContentResolver, uri: Uri): String {
        resolver.query(uri, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: "selected-file"
        }
        return "selected-file"
    }

    fun listTree(resolver: ContentResolver, tree: Uri): List<String> {
        val root = DocumentsContract.getTreeDocumentId(tree)
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, root)
        val out = mutableListOf<String>()
        resolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE), null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(1) ?: "(unnamed)"
                val isDir = c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR
                out += (if (isDir) "[Folder] " else "[File] ") + name
            }
        }
        return out.sorted()
    }

    fun copyAndVerify(resolver: ContentResolver, source: Uri, destinationTree: Uri, requestedName: String): CopyResult {
        require(requestedName.isNotBlank() && !requestedName.contains('/') && !requestedName.contains('\\')) { "Enter a simple destination filename." }
        val rootId = DocumentsContract.getTreeDocumentId(destinationTree)
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(destinationTree, rootId)
        resolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { c ->
            while (c.moveToNext()) if (c.getString(0).equals(requestedName, true)) error("A file with that name already exists. Choose another name; overwrite is disabled in this prototype.")
        }
        val mime = resolver.getType(source) ?: "application/octet-stream"
        val rootDocument = DocumentsContract.buildDocumentUriUsingTree(destinationTree, rootId)
        val created = DocumentsContract.createDocument(resolver, rootDocument, mime, requestedName)
            ?: error("Android could not create the destination file.")
        try {
            val digestIn = MessageDigest.getInstance("SHA-256")
            var byteCount = 0L
            resolver.openInputStream(source).use { input ->
                requireNotNull(input) { "Could not open source file." }
                resolver.openOutputStream(created, "w").use { output ->
                    requireNotNull(output) { "Could not open destination file." }
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buffer); if (n < 0) break
                        output.write(buffer, 0, n); digestIn.update(buffer, 0, n); byteCount += n
                    }
                    output.flush()
                }
            }
            val sourceHash = digestIn.digest().joinToString("") { "%02x".format(it) }
            val digestOut = MessageDigest.getInstance("SHA-256")
            var copiedBytes = 0L
            resolver.openInputStream(created).use { input ->
                requireNotNull(input) { "Could not verify destination." }
                val buffer = ByteArray(64 * 1024)
                while (true) { val n = input.read(buffer); if (n < 0) break; digestOut.update(buffer, 0, n); copiedBytes += n }
            }
            val destHash = digestOut.digest().joinToString("") { "%02x".format(it) }
            if (byteCount != copiedBytes || sourceHash != destHash) error("Verification failed: destination bytes/hash do not match source.")
            return CopyResult(requestedName, copiedBytes, destHash)
        } catch (e: Exception) {
            runCatching { DocumentsContract.deleteDocument(resolver, created) }
            throw e
        }
    }
}
