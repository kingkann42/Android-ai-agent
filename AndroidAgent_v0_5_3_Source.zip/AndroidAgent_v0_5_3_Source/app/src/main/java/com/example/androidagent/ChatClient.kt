package com.example.androidagent

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

internal object ChatClient {
    fun reply(
        server: String,
        model: String,
        openWebUi: Boolean,
        apiKey: String,
        extraHeadersText: String,
        message: String
    ): String {
        val base = server.trim().trimEnd('/')
        val path = if (openWebUi) "/api/chat/completions" else "/api/chat"
        val url = URL(base + path)

        require(url.protocol == "https" || url.protocol == "http") {
            "Server must start with https:// or http://"
        }
        require(model.isNotBlank()) { "Choose a model in the Agent tab first." }

        val headers = parseHeaders(extraHeadersText)
        val sendKey = openWebUi && apiKey.isNotBlank()
        require(url.protocol == "https" || (!sendKey && headers.isEmpty())) {
            "Use HTTPS before sending an API key or custom headers."
        }

        val messages = JSONArray().put(
            JSONObject().put("role", "user").put("content", message)
        )
        val body = JSONObject()
            .put("model", model.trim())
            .put("messages", messages)
            .put("stream", false)

        val connection = url.openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.instanceFollowRedirects = false
            connection.connectTimeout = 15_000
            connection.readTimeout = 120_000
            connection.doOutput = true

            headers.forEach { (name, value) ->
                connection.setRequestProperty(name, value)
            }
            connection.setRequestProperty("Content-Type", "application/json")
            if (sendKey) {
                connection.setRequestProperty("Authorization", "Bearer ${apiKey.trim()}")
            }

            connection.outputStream.use {
                it.write(body.toString().toByteArray(Charsets.UTF_8))
            }

            val code = connection.responseCode
            check(code in 200..299) {
                when (code) {
                    401, 403 -> "HTTP $code: check the API key and model permissions."
                    404 -> "HTTP 404: check the server base address, provider, and model name."
                    else -> "Chat server returned HTTP $code."
                }
            }

            val json = connection.inputStream.bufferedReader(Charsets.UTF_8).use {
                JSONObject(it.readText())
            }
            val answer = if (openWebUi) {
                json.getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").getString("content")
            } else {
                json.getJSONObject("message").getString("content")
            }

            return answer.trim().ifEmpty { "The model returned an empty reply." }
        } finally {
            connection.disconnect()
        }
    }

    // Accept either a JSON object or one "Name: Value" header per line.
    private fun parseHeaders(raw: String): Map<String, String> {
        val text = raw.trim()
        if (text.isEmpty()) return emptyMap()

        if (text.startsWith("{")) {
            val obj = JSONObject(text)
            return obj.keys().asSequence().associateWith { obj.getString(it) }
        }

        return text.lineSequence().filter { it.isNotBlank() }.associate { line ->
            val split = line.indexOf(':')
            require(split > 0) { "Use Name: Value for each custom header." }
            line.substring(0, split).trim() to line.substring(split + 1).trim()
        }
    }
}