package com.example.androidagent

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

@Composable
private fun AgentChatInput(
    draft: String,
    onDraftChange: (String) -> Unit,
    sending: Boolean,
    onSend: (String) -> Unit
) }
{
    Column(
        modifier = Modifier.fillMaxWidth().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        OutlinedTextField(
            value = draft,
            onValueChange = onDraftChange,
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Message your agent") },
            minLines = 1,
            maxLines = 4
        )

        Button(
            enabled = draft.isNotBlank() && !sending,
            onClick = { onSend(draft.trim()) }
        ) {
            Text(if (sending) "Sending…" else "Send")
        }
    }
}
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = LocalStore(this)
        val prefs = getSharedPreferences("agent_settings", MODE_PRIVATE)
        setContent { MaterialTheme { AgentScreen(store, prefs) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AgentScreen(store: LocalStore, prefs: android.content.SharedPreferences) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val catalog = remember(context) { AppCatalog(context) }
    var server by remember { mutableStateOf(prefs.getString("server", "https://100.91.123.85:8443") ?: "https://100.91.123.85:8443") }
    var model by remember { mutableStateOf(prefs.getString("model", "qwen3.8:27b-q8_0") ?: "qwen3.8:27b-q8_0") }
    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var extraHeadersText by remember { mutableStateOf(prefs.getString("extra_headers", "") ?: "") }
    var testResult by remember { mutableStateOf("") }
    var testing by remember { mutableStateOf(false) }
    var useOpenWebUi by remember { mutableStateOf((prefs.getString("provider", "openwebui") ?: "openwebui") == "openwebui") }
    val aiProvider: AiProvider = if (useOpenWebUi) OpenWebUiProvider() else OllamaProvider()
    var allowlistedPackage by remember { mutableStateOf(prefs.getString("allowlist", "") ?: "") }
    var request by rememberSaveable { mutableStateOf("") }
    val tabNames = listOf("Agent", "Chat", "Web", "Memory")
var activeTab by rememberSaveable { mutableStateOf("Agent") }
var chatDraft by rememberSaveable { mutableStateOf("") }
var chatReply by rememberSaveable { mutableStateOf("") }
var chatSending by remember { mutableStateOf(false) }
var webQuery by rememberSaveable { mutableStateOf("") }
var webError by remember { mutableStateOf("") }

val memoryKey = "agent_user_note_v1"
var savedNote by remember {
    mutableStateOf(prefs.getString(memoryKey, "").orEmpty())
}
var noteDraft by rememberSaveable { mutableStateOf(savedNote) }
    var connectionOpen by rememberSaveable { mutableStateOf(false) }
    var showDetails by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Preview a plan, then review each step before it runs.") }
    var busy by remember { mutableStateOf(false) }
    var plan by remember { mutableStateOf<AgentPlan?>(null) }
    var apps by remember { mutableStateOf(emptyList<LaunchableApp>()) }
    var appSearch by remember { mutableStateOf("") }
    var appStatus by remember { mutableStateOf("Discover apps to populate the launcher list.") }
    var tasks by remember { mutableStateOf(store.tasks()) }
    var logs by remember { mutableStateOf(store.logs()) }
    var selectedFile by remember { mutableStateOf<android.net.Uri?>(null) }
    var selectedFolder by remember { mutableStateOf<android.net.Uri?>(null) }
    var fileName by remember { mutableStateOf("") }
    var folderContents by remember { mutableStateOf(emptyList<String>()) }
    var fileStatus by remember { mutableStateOf("Select a source file and a destination folder to test safe file copying.") }
    var tapText by remember { mutableStateOf("") }
    var accessibilityStatus by remember { mutableStateOf("Accessibility is optional and off until you enable it in Android Settings.") }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            selectedFile = uri
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            fileName = FileTools.displayName(context.contentResolver, uri)
            fileStatus = "Source selected: $fileName"
        }
    }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            selectedFolder = uri
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
            folderContents = runCatching { FileTools.listTree(context.contentResolver, uri) }.getOrElse { emptyList() }
            fileStatus = "Destination folder selected. ${folderContents.size} immediate entries visible."
        }
    }
    val speechPicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) request = spoken
    }

    fun refreshApps() {
        apps = catalog.discover()
        appStatus = "Found ${apps.size} launchable apps visible to Android."
    }
    fun refreshLogs() { tasks = store.tasks(); logs = store.logs() }
    fun executeStep(step: ProposedStep) {
        if (store.wasExecuted(step.id)) { status = "Duplicate execution blocked for this task step."; return }
        val error = ActionPolicy.validate(step)
        if (error != null) {
            status = error
            plan = plan?.copy(steps = plan!!.steps.map { if (it.id == step.id) it.copy(status = StepStatus.REJECTED) else it })
            return
        }
        val result = when (step.tool) {
            "open_app" -> {
                val pkg = step.arguments["package_name"].orEmpty()
                if (apps.none { it.packageName == pkg }) ToolResult.Failure("The requested app is not in the current visible launcher catalog. Refresh discovery first.")
                else catalog.launch(pkg).fold({ ToolResult.Success("Launch requested for $pkg") }, { ToolResult.Failure(it.message ?: "App launch failed") })
            }
            else -> store.execute(step)
        }
        val success = result is ToolResult.Success
        val message = when (result) { is ToolResult.Success -> result.message; is ToolResult.Failure -> result.message }
        if (step.tool == "open_app") store.log(step, if (success) "LAUNCH_REQUESTED" else "FAILED", message)
        status = message
        plan = plan?.copy(steps = plan!!.steps.map { if (it.id == step.id) it.copy(status = if (success) StepStatus.COMPLETED else StepStatus.FAILED) else it })
        refreshLogs()
    }

    Scaffold(
    topBar = {
        Column {
            TopAppBar(title = { Text("Android Agent") })
            TabRow(selectedTabIndex = tabNames.indexOf(activeTab)) {
                tabNames.forEach { name ->
                    Tab(
                        selected = activeTab == name,
                        onClick = { activeTab = name },
                        text = { Text(name) }
                    )
                }
            }
        }
    }
) { padding ->
    if (activeTab != "Agent") {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (activeTab) {
                "Chat" -> {
                    item {
                        Text("Try: What do you remember?")
                    }
                    item {
                        AgentChatInput(
    draft = chatDraft,
    onDraftChange = { chatDraft = it },
    sending = chatSending,
    onSend = { message ->
        val question = message.trim().trimEnd('?')

        if (question.equals("What do you remember", ignoreCase = true)) {
            // Local lookup: no network request and no API key needed.
            chatReply = savedNote.ifBlank { "No memory saved yet." }
        } else {
            val selectedServer = server
            val selectedModel = model
            val selectedProvider = useOpenWebUi
            val selectedKey = apiKey
            val selectedHeaders = extraHeadersText

            chatSending = true
            chatReply = "Waiting for a reply…"

            scope.launch {
                try {
                    chatReply = withContext(Dispatchers.IO) {
                        ChatClient.reply(
                            server = selectedServer,
                            model = selectedModel,
                            openWebUi = selectedProvider,
                            apiKey = selectedKey,
                            extraHeadersText = selectedHeaders,
                            message = message
                        )
                    }
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) {
                    chatReply = "Chat failed: ${e.localizedMessage ?: "connection error"}"
                } finally {
                    chatSending = false
                }
            }
        }
    }
 )
+                    } // closes the item containing AgentChatInput
                     if (chatReply.isNotBlank()) {
                         item { Text(chatReply) }
                     }
                 }
 
                 "Web" -> {
                    item {
                        OutlinedTextField(
                            value = webQuery,
                            onValueChange = {
                                webQuery = it
                                webError = ""
                            },
                            label = { Text("Search the web") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    item {
                        Button(
                            enabled = webQuery.isNotBlank(),
                            onClick = {
                                val uri = android.net.Uri
                                    .parse("https://www.google.com/search")
                                    .buildUpon()
                                    .appendQueryParameter("q", webQuery.trim())
                                    .build()
                                try {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                                } catch (_: android.content.ActivityNotFoundException) {
                                    webError = "No browser was found on this device."
                                }
                            }
                        ) {
                            Text("Search in browser")
                        }
                    }
                    item {
                        Text("Only your search terms go to the browser. Your saved note is not included.")
                    }
                    if (webError.isNotBlank()) {
                        item { Text(webError) }
                    }
                }

                "Memory" -> {
                    item {
                        OutlinedTextField(
                            value = noteDraft,
                            onValueChange = { noteDraft = it.take(4000) },
                            label = { Text("Note for the agent to remember") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 3
                        )
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                enabled = noteDraft.isNotBlank() && noteDraft != savedNote,
                                onClick = {
                                    savedNote = noteDraft.trim()
                                    noteDraft = savedNote
                                    prefs.edit().putString(memoryKey, savedNote).apply()
                                }
                            ) {
                                Text("Save note")
                            }
                            OutlinedButton(
                                enabled = savedNote.isNotEmpty() || noteDraft.isNotEmpty(),
                                onClick = {
                                    prefs.edit().remove(memoryKey).apply()
                                    savedNote = ""
                                    noteDraft = ""
                                }
                            ) {
                                Text("Clear")
                            }
                        }
                    }
                    item {
                        Text(
                            when {
                                noteDraft != savedNote -> "Unsaved changes"
                                savedNote.isEmpty() -> "No saved note"
                                else -> "Saved on this device"
                            }
                        )
                    }
                }
            }
        }
        return@Scaffold
    }

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 28.dp)
        ) {
        item {
                Text("Supported ABIs: " + android.os.Build.SUPPORTED_ABIS.joinToString())
                val probeStatus = androidx.compose.runtime.remember {
                    try {
                        System.loadLibrary("agent_probe")
                        "Offline native test: PASS"
                    } catch (e: UnsatisfiedLinkError) {
                        "Offline native test: FAILED — ${e.message}"
                    }
                }
                Text(probeStatus)
            }
            item {
                val context = androidx.compose.ui.platform.LocalContext.current
                val status = androidx.compose.runtime.remember {
                    androidx.compose.runtime.mutableStateOf("No model file checked yet.")
                }

                val picker = androidx.activity.compose.rememberLauncherForActivityResult(
                    contract = androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
                ) { uri ->
                    if (uri != null) {
                        status.value = try {
                            val resolver = context.contentResolver
                            val isGguf = resolver.openInputStream(uri)?.use { input ->
                                input.read() == 'G'.code &&
                                    input.read() == 'G'.code &&
                                    input.read() == 'U'.code &&
                                    input.read() == 'F'.code
                            } ?: false

                            if (isGguf) {
                                resolver.takePersistableUriPermission(
                                    uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                                )
                                context.getSharedPreferences("offline_model", 0)
                                    .edit().putString("model_uri", uri.toString()).apply()
                                "GGUF header found. Model file selection saved."
                            } else {
                                "Not a GGUF file. Choose the downloaded .gguf file."
                            }
                        } catch (e: Exception) {
                            "Could not open or save access to this file: ${e.message}"
                        }
                    }
                }

                Column {
                    OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }) {
                        Text("Choose model file")
                    }
                    val loading = androidx.compose.runtime.remember {
                        androidx.compose.runtime.mutableStateOf(false)
                    }
                    OutlinedButton(
                        enabled = !loading.value,
                        onClick = {
                            loading.value = true
                            status.value = "Loading model on this phone…"
                            scope.launch {
                                try {
                                    status.value = withContext(Dispatchers.IO) {
                                        LocalModelBridge.testSavedModel(context.applicationContext)
                                    }
                                } finally {
                                    loading.value = false
                                }
                            }
                        }
                    ) {
                        Text(if (loading.value) "Loading…" else "Test local model load")
                    }
                    OutlinedButton(
                        enabled = !loading.value,
                        onClick = {
                            loading.value = true
                            status.value = "Asking the local model: What is 2 + 2?"
                            scope.launch {
                                try {
                                    status.value = withContext(Dispatchers.IO) {
                                        LocalModelBridge.testSavedModel(context, wantReply = true)
                                    }
                                } finally {
                                    loading.value = false
                                }
                            }
                        }
                    ) {
                        Text("Test offline reply")
                    }
                            val offlineQuestion = androidx.compose.runtime.remember {
                        androidx.compose.runtime.mutableStateOf("")
                    }

                    OutlinedTextField(
                        value = offlineQuestion.value,
                        onValueChange = { offlineQuestion.value = it },
                        enabled = !loading.value,
                        label = { Text("Ask the on-device model") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedButton(
                        enabled = !loading.value && offlineQuestion.value.isNotBlank(),
                        onClick = {
                            val question = offlineQuestion.value.trim()
                            loading.value = true
                            status.value = "Generating a reply on this phone…"
                            scope.launch {
                                try {
                                    status.value = withContext(Dispatchers.IO) {
                                        LocalModelBridge.testSavedModel(
                                            context, wantReply = true, question = question
                                        )
                                    }
                                } finally {
                                    loading.value = false
                                }
                            }
                        }
                    ) {
                        Text("Ask offline")
                    }

                    Text(status.value)
                }
            }
            item {
                OutlinedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("AI connection", style = MaterialTheme.typography.titleMedium)
                        Text(server.ifBlank { "No server configured" }, style = MaterialTheme.typography.bodySmall)
                        TextButton(enabled = !busy, onClick = { connectionOpen = !connectionOpen }) {
                            Text(if (connectionOpen) "Hide settings" else "Edit connection")
                        }
                        if (connectionOpen) {
                            OutlinedTextField(
                                value = server, onValueChange = { server = it },
                                label = { Text("Server base URL") }, enabled = !busy,
                                singleLine = true, modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = model, onValueChange = { model = it },
                                label = { Text("Model ID") }, enabled = !busy,
                                singleLine = true, modifier = Modifier.fillMaxWidth()
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Switch(checked = useOpenWebUi, onCheckedChange = { useOpenWebUi = it }, enabled = !busy)
                                Text(
                                    if (useOpenWebUi) "Open WebUI (OpenAI-style API, key required)" else "Ollama (native API)",
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            OutlinedTextField(
                                value = apiKey, onValueChange = { apiKey = it },
                                label = { Text("API key (Open WebUI)") }, enabled = !busy && useOpenWebUi,
                                singleLine = true, visualTransformation = PasswordVisualTransformation(),
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = extraHeadersText, onValueChange = { extraHeadersText = it },
                                label = { Text("Extra headers (optional, one per line: Name: value)") }, enabled = !busy,
                                minLines = 2, modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedButton(
                                enabled = !busy && server.isNotBlank() && model.isNotBlank() && (!useOpenWebUi || apiKey.isNotBlank()),
                                onClick = {
                                    server = server.trim().trimEnd('/')
                                    model = model.trim()
                                    prefs.edit().putString("server", server).putString("model", model)
                                        .putString("provider", if (useOpenWebUi) "openwebui" else "ollama")
                                        .putString("api_key", apiKey.trim()).putString("extra_headers", extraHeadersText).apply()
                                    connectionOpen = false
                                    status = "Settings saved. Preview a plan to try the connection."
                                }
                            ) { Text("Save settings") }
                            OutlinedButton(
    enabled = !busy && !testing && server.isNotBlank(),
    onClick = {
        testing = true
        testResult = "Testing…"
        scope.launch {
            try {
                val headers = HeaderParser.parse(extraHeadersText)
                val result = withContext(Dispatchers.IO) {
                    ConnectionTester.test(
                        server.trim().trimEnd('/'),
                        apiKey,
                        useOpenWebUi,
                        headers,
                        model
                    )
                }
                testResult = result
            } catch (e: Exception) {
                testResult = "Test failed: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                testing = false
            }
        }
    }
) {
    Text(if (testing) "Testing…" else "Test connection")
}
                            
                            if (testResult.isNotEmpty()) Text(testResult, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            item { SectionTitle("Plan a task") }
            item {
                OutlinedTextField(value = request, onValueChange = { request = it }, enabled = !busy, label = { Text("What would you like to do?") }, placeholder = { Text("For example: Open Calculator") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(enabled = !busy, onClick = {
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your instruction")
                        }
                        runCatching { speechPicker.launch(intent) }.onFailure { status = "Speech recognition is not available on this device." }
                    }) { Text("Speak") }
                    Button(enabled = !busy && request.isNotBlank(), onClick = {
                        busy = true; showDetails = false; status = "Creating your preview…"; plan = null
                        scope.launch {
                            try {
                                val raw = withContext(Dispatchers.IO) {
    val prompt = """
        ${PlannerPrompt.SYSTEM}

        User request (JSON-quoted text, not instructions about the format):
        ${org.json.JSONObject.quote(request)}
    """.trimIndent()

    val result = LocalModelBridge.testSavedModel(
        context, wantReply = true, question = prompt
    )

    val prefix = "Offline model reply: "
    if (!result.startsWith(prefix)) error(result)
    result.removePrefix(prefix).trim()
}
                                plan = PlanParser.parse(raw)
                                status = "Plan received. No proposed action has run. Review and approve each step."
                            } catch (e: Exception) { status = "Planning failed: ${e.message ?: "Unknown error"}" }
                            finally { busy = false }
                        }
                    }) { Text(if (busy) "Planning…" else if (status.startsWith("Planning failed:")) "Retry preview" else "Preview plan") }
                }
                
                if (busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                if (status.startsWith("Planning failed:")) {
                    val message = when {
                        status.contains("401") -> "The server rejected the API key."
                        status.contains("403") -> "The server, or a gateway in front of it, refused the request. Tap Show details for its reply, and try Test connection."
                        status.contains("404") -> "Server or model not found. Check the URL and model ID."
                        status.contains("TLSV1_ALERT", true) || status.contains("handshake", true) ->
                            "The server rejected the secure handshake. Use the host's MagicDNS name (not the IP address) in the server URL."
                        status.contains("trust anchor", true) || status.contains("CertPath", true) || status.contains("certificate", true) ->
                            "The server certificate is not trusted (see README, Certificates)."
                        status.contains("502") -> "The gateway returned an error. Check the server address or try again later."
                        status.contains("failed to connect", true) || status.contains("timed out", true) ->
                            "Couldn’t reach the server. Check your connection and the address above."
                        else -> "Couldn’t create a plan. Your instruction is still here."
                    }
                    Text(message, color = MaterialTheme.colorScheme.error)
                    TextButton(onClick = { showDetails = !showDetails }) {
                        Text(if (showDetails) "Hide details" else "Show details")
                    }
                    if (showDetails) Text(status, style = MaterialTheme.typography.bodySmall)
                } else {
                    Text(status, style = MaterialTheme.typography.bodyMedium)
                }
            }
            plan?.let { current ->
                item { Text(current.summary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
                items(current.steps, key = { it.id }) { step ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(step.tool, fontWeight = FontWeight.Bold)
                            Text(step.explanation)
                            Text("Risk: ${step.risk} · Status: ${step.status}", style = MaterialTheme.typography.bodySmall)
                            step.arguments.forEach { (key, value) -> Text("$key: $value", style = MaterialTheme.typography.bodySmall) }
                            if (step.status == StepStatus.AWAITING_APPROVAL) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = { executeStep(step) }) { Text("Approve & run") }
                                    OutlinedButton(onClick = {
                                        plan = current.copy(steps = current.steps.map { if (it.id == step.id) it.copy(status = StepStatus.REJECTED) else it })
                                        store.log(step, "REJECTED", "User rejected proposal")
                                        refreshLogs()
                                    }) { Text("Reject") }
                                }
                            }
                        }
                    }
                }
            }
            item { Divider(); SectionTitle("Apps") }
            item {
                Text("Only launcher-visible apps are listed. Opening an app from this catalog is a direct Android launch; it does not grant access to the app's private data.", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { refreshApps() }) { Text("Discover apps") }
                    OutlinedTextField(value = appSearch, onValueChange = { appSearch = it }, label = { Text("Filter") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                Text(appStatus, style = MaterialTheme.typography.bodySmall)
            }
            items(apps.filter { it.label.contains(appSearch, true) || it.packageName.contains(appSearch, true) }, key = { it.packageName }) { app ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) { Text(app.label, fontWeight = FontWeight.SemiBold); Text(app.packageName, style = MaterialTheme.typography.bodySmall) }
                        OutlinedButton(onClick = {
                            catalog.launch(app.packageName).fold(
                                { store.record("open_app", "LAUNCH_REQUESTED", app.packageName); appStatus = "Launch requested: ${app.label}" },
                                { store.record("open_app", "FAILED", app.packageName); appStatus = "Launch failed: ${it.message}" }
                            ); refreshLogs()
                        }) { Text("Open") }
                    }
                }
            }
            item { Divider(); SectionTitle("Files") }
            item {
                Text("The system picker grants access only to the file/folder you select. Android protected app-data folders remain unavailable.", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { filePicker.launch(arrayOf("*/*")) }) { Text("Choose source file") }
                    OutlinedButton(onClick = { folderPicker.launch(null) }) { Text("Choose destination folder") }
                }
                Text("Source: ${selectedFile?.let { fileName } ?: "not selected"}", style = MaterialTheme.typography.bodySmall)
                Text("Destination: ${if (selectedFolder == null) "not selected" else "selected"}", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(value = fileName, onValueChange = { fileName = it }, label = { Text("Destination filename") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Button(enabled = selectedFile != null && selectedFolder != null && fileName.isNotBlank(), onClick = {
                    val src = selectedFile!!; val dest = selectedFolder!!; val name = fileName
                    fileStatus = "Copying and verifying…"
                    scope.launch {
                        try {
                            val result = withContext(Dispatchers.IO) { FileTools.copyAndVerify(context.contentResolver, src, dest, name) }
                            fileStatus = "Verified copy: ${result.name} · ${result.bytes} bytes · SHA-256 ${result.sha256}"
                            store.record("copy_file", "VERIFIED", "${result.name}; ${result.bytes} bytes; ${result.sha256}")
                            folderContents = runCatching { FileTools.listTree(context.contentResolver, dest) }.getOrElse { emptyList() }
                            refreshLogs()
                        } catch (e: Exception) { fileStatus = "Copy failed: ${e.message}"; store.record("copy_file", "FAILED", e.message ?: "Unknown error"); refreshLogs() }
                    }
                }) { Text("Copy and verify") }
                Text(fileStatus, style = MaterialTheme.typography.bodySmall)
                if (folderContents.isNotEmpty()) Text("Folder entries: ${folderContents.take(12).joinToString(", ")}", style = MaterialTheme.typography.bodySmall)
            }
            item { Divider(); SectionTitle("Optional accessibility tools") }
            item {
                Text("Accessibility is off by default. Enable it only if you want to test task-scoped UI interaction. The service does not collect event text or run background actions.", style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("Open Accessibility settings") }
                OutlinedTextField(value = allowlistedPackage, onValueChange = { allowlistedPackage = it }, label = { Text("Allowed app package name") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = { prefs.edit().putString("allowlist", allowlistedPackage.trim()).apply(); accessibilityStatus = "Saved one-app allowlist: ${allowlistedPackage.trim()}" }) { Text("Save allowlist") }
                OutlinedTextField(value = tapText, onValueChange = { tapText = it }, label = { Text("Exact visible text to tap") }, modifier = Modifier.fillMaxWidth())
                OutlinedButton(enabled = tapText.isNotBlank() && allowlistedPackage.isNotBlank(), onClick = {
                    val svc = AgentAccessibilityService.active
                    val ok = svc?.clickVisibleText(tapText, setOf(allowlistedPackage.trim())) == true
                    accessibilityStatus = if (ok) "Tap action sent to a matching visible control." else "No matching clickable control, service disabled, or active app not allowlisted."
                    store.record("accessibility_tap", if (ok) "ACTION_SENT" else "BLOCKED_OR_NOT_FOUND", "package=${allowlistedPackage.trim()}")
                    refreshLogs()
                }) { Text("Tap approved visible text") }
                Text(accessibilityStatus, style = MaterialTheme.typography.bodySmall)
            }
            item { Divider(); SectionTitle("History") }
            item { OutlinedButton(onClick = { refreshLogs() }) { Text("Refresh history") } }
            item { Text("Tasks", fontWeight = FontWeight.SemiBold) }
            items(tasks) { Text("• $it", style = MaterialTheme.typography.bodySmall) }
            item { Text("Recent actions", fontWeight = FontWeight.SemiBold) }
            items(logs) { Text("• $it", style = MaterialTheme.typography.bodySmall) }
            item {
                Divider()
                Text("Prototype boundaries: no root, no shell execution, no SMS/calls/purchases/deletion, no private app-data access, no automatic background listening. Model output is untrusted and must pass local schema validation and user approval.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
}
