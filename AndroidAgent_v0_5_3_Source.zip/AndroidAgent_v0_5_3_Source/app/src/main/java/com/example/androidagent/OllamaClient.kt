package com.example.androidagent

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object OllamaClient {
    fun generatePlan(baseUrl: String, model: String, userRequest: String, extraHeaders: Map<String, String> = emptyMap()): String {
        require(baseUrl.startsWith("http://") || baseUrl.startsWith("https://")) { "Server URL must begin with http:// or https://" }
        require(userRequest.length <= 8000) { "Request is too long (maximum 8,000 characters)." }
        val system = PlannerPrompt.SYSTEM
        val body = JSONObject().apply {
            put("model", model)
            put("stream", false)
            put("format", "json")
            put("think", false)
            put("keep_alive", "30m")
            put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", system))
                .put(JSONObject().put("role", "user").put("content", userRequest)))
        }
        val conn = (URL(baseUrl.trimEnd('/') + "/api/chat").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 12000
            readTimeout = 300000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            extraHeaders.forEach { (k, v) -> setRequestProperty(k, v) }
        }
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) error("Ollama HTTP $code: ${response.take(500)}")
            val content = JSONObject(response).getJSONObject("message").optString("content", "")
            if (content.isBlank()) error("Model returned empty content")
            return content
        } finally { conn.disconnect() }
    }
}
