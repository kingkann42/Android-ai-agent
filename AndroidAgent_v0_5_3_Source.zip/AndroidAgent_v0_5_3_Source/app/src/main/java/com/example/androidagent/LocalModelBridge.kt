package com.example.androidagent

import android.content.Context
import android.net.Uri

object LocalModelBridge {
    private external fun checkModel(fd: Int): Boolean

    @Synchronized
    fun testSavedModel(context: Context): String {
        val saved = context.getSharedPreferences("offline_model", Context.MODE_PRIVATE)
            .getString("model_uri", null)
            ?: return "Choose a model file first."

        return try {
            System.loadLibrary("agent_probe")
            val uri = Uri.parse(saved)
            val descriptor = context.contentResolver.openFileDescriptor(uri, "r")
                ?: return "Android could not open the selected file."

            val loaded = descriptor.use { checkModel(it.fd) }
            if (loaded) {
                "Offline model load: PASS. Model released."
            } else {
                "Model load failed. Check that the GGUF download is complete and selected from local Downloads."
            }
        } catch (e: UnsatisfiedLinkError) {
            "Native library error: ${e.message}"
        } catch (e: Exception) {
            "Could not read the saved model: ${e.message}"
        }
    }
}