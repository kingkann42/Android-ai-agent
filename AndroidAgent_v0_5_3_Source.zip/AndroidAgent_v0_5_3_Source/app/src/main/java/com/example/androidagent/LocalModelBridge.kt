package com.example.androidagent

import android.content.Context
import android.net.Uri
import java.io.File

object LocalModelBridge {
    private external fun checkModel(
        path: String, wantReply: Boolean, questionBytes: ByteArray
    ): ByteArray?

    @Synchronized
    fun testSavedModel(
        context: Context,
        wantReply: Boolean = false,
        question: String = "What is 2 + 2? Reply with only the number."
    ): String {
        val saved = context.getSharedPreferences("offline_model", Context.MODE_PRIVATE)
            .getString("model_uri", null)
            ?: return "Choose a model file first."

        return try {
            System.loadLibrary("agent_probe")
            runTest(context, Uri.parse(saved), wantReply, question)
        } catch (e: UnsatisfiedLinkError) {
            "Native library error: ${e.message}"
        } catch (e: Exception) {
            "Offline model test failed: ${e.message}"
        }
    }

     private fun runTest(
        context: Context, uri: Uri, wantReply: Boolean, question: String
    ): String {
        val questionBytes = question.trim().toByteArray(Charsets.UTF_8)
        if (wantReply && questionBytes.isEmpty()) return "Enter a question first."
        if (wantReply && questionBytes.size > 2048) return "Try a shorter question."
        val temp = File.createTempFile("model-test-", ".gguf", context.cacheDir)
        try {
            val input = context.contentResolver.openInputStream(uri)
                ?: return "Android could not open the selected file."

            val bytes = input.use { source ->
                temp.outputStream().use { destination -> source.copyTo(destination) }
            }
            if (bytes == 0L) return "The selected file is empty."

            val output = checkModel(temp.absolutePath, wantReply, questionBytes)
                ?: return "Native test returned no result."

            if (!wantReply) return "Offline model load: PASS. Model released."

            val text = output.toString(Charsets.UTF_8).trim()
            return if (text.isEmpty()) "Model generated only whitespace."
            else "Offline model reply: $text"
        } finally {
            temp.delete()
        }
    }
}