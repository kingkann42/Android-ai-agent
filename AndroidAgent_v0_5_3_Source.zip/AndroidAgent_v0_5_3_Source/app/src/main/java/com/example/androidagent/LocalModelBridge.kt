package com.example.androidagent

import android.content.Context
import android.net.Uri
import java.io.File

object LocalModelBridge {
    private external fun checkModel(path: String, wantReply: Boolean): ByteArray?

    @Synchronized
fun testSavedModel(context: Context, wantReply: Boolean = false): String {
        val saved = context.getSharedPreferences("offline_model", Context.MODE_PRIVATE)
            .getString("model_uri", null)
            ?: return "Choose a model file first."

        return try {
            System.loadLibrary("agent_probe")
            val temp = File.createTempFile("model-test-", ".gguf", context.cacheDir)

            try {
                val input = context.contentResolver.openInputStream(Uri.parse(saved))
                    ?: return "Android could not open the selected file."

                val bytes = input.use { source ->
                    temp.outputStream().use { destination ->
                        source.copyTo(destination)
                    }
                }

                if (bytes == 0L) {
                    "The selected file is empty."
                } else {
                    val output = checkModel(temp.absolutePath, wantReply)
                    when {
                        output == null -> "Native test returned no result."
                        !wantReply -> "Offline model load: PASS. Model released."
                        else -> {
                            val text = output.toString(Charsets.UTF_8).trim()
                            if (text.isEmpty()) "Model generated only whitespace."
                            else "Offline model reply: $text"
                        }
                    }
                }
                }
            } finally {
                temp.delete()
            }
        } catch (e: UnsatisfiedLinkError) {
            "Native library error: ${e.message}"
        } catch (e: Exception) {
            "Offline model test failed: ${e.message}"
        }
    }
}