package com.example.androidagent

import org.json.JSONObject

object PlanParser {
    fun parse(raw: String): AgentPlan {
        // Drop reasoning blocks some models emit, then take the outermost JSON object.
        val visible = raw.replace(Regex("(?s)<think>.*?</think>"), "").trim()
        require(visible.isNotBlank()) { "Model returned an empty reply." }
        val start = visible.indexOf('{')
        val end = visible.lastIndexOf('}')
        require(start >= 0 && end > start) { "Model reply did not contain a JSON object: ${visible.take(200)}" }
        val json = JSONObject(visible.substring(start, end + 1))
        val summary = json.optString("summary", "Proposed actions")
        val array = json.optJSONArray("steps") ?: return AgentPlan(summary, emptyList())
        require(array.length() <= 8) { "The plan contains more than 8 steps." }
        val steps = buildList {
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: error("Step $i is not an object.")
                val argJson = item.optJSONObject("arguments") ?: JSONObject()
                val args = linkedMapOf<String, String>()
                val keys = argJson.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val value = argJson.opt(key)
                    require(value is String) { "Only string arguments are accepted." }
                    args[key] = value
                }
                val tool = item.optString("tool", "")
                val step = ProposedStep(
                    tool = tool,
                    arguments = args,
                    explanation = item.optString("explanation", ""),
                    risk = ActionPolicy.assess(tool)
                )
                // Unsupported/blocked steps remain visible but can never be approved.
                add(step.copy(status = if (ActionPolicy.validate(step) == null) StepStatus.AWAITING_APPROVAL else StepStatus.REJECTED))
            }
        }
        return AgentPlan(summary, steps)
    }
}
