cmake_minimum_required(VERSION 3.22.1)
project(agent_probe LANGUAGES C)

add_library(agent_probe SHARED probe.c)