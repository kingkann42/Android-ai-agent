cmake_minimum_required(VERSION 3.22.1)
project(agent_probe LANGUAGES C CXX)

include(FetchContent)

# Build the CPU library, not desktop apps, servers, or tests.
set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(GGML_NATIVE OFF CACHE BOOL "" FORCE)
set(GGML_OPENMP OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_COMMON OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TOOLS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_SERVER OFF CACHE BOOL "" FORCE)

FetchContent_Declare(
    llama_cpp
    URL https://github.com/ggml-org/llama.cpp/archive/refs/tags/v1.0.0.tar.gz
)
FetchContent_MakeAvailable(llama_cpp)

# Keep the native library name that MainActivity already loads.
add_library(agent_probe SHARED probe.c)
target_link_libraries(agent_probe PRIVATE llama)
set_target_properties(agent_probe PROPERTIES LINKER_LANGUAGE CXX)