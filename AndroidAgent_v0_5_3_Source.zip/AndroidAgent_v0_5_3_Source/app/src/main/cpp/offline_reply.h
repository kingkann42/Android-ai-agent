#pragma once

#include "llama.h"
#include <memory>
#include <string>
#include <vector>

// Fixed test for the downloaded Qwen2.5-Instruct model.
// Returns nullptr on success or an error message on failure.
static const char *generate_test_reply(
        llama_model *model, const std::string &question, std::string &reply) {
    const llama_vocab *vocab = llama_model_get_vocab(model);
    if (!vocab) return "Model has no vocabulary.";

    const std::string prompt =
        std::string("<|im_start|>user\n") + question +
        "<|im_end|>\n<|im_start|>assistant\n";

    constexpr int max_output = 512;<br> constexpr int context_size = 2048;
    const int needed = llama_tokenize(
        vocab, prompt.data(), prompt.size(), nullptr, 0, false, true
    );
    if (needed >= 0) return "Could not measure the prompt.";
    if (needed < -(context_size - max_output))
        return "Question is too long. Try a shorter question.";

    std::vector<llama_token> tokens(-needed);
    const int count = llama_tokenize(
        vocab, prompt.data(), prompt.size(),
        tokens.data(), tokens.size(), false, true
    );
    if (count <= 0 || count > static_cast<int>(tokens.size()))
        return "Could not tokenize the test prompt.";

    auto cp = llama_context_default_params();
    cp.n_ctx = context_size;
    cp.n_batch = count;

    // These objects release themselves on every return, including errors.
    std::unique_ptr<llama_context, decltype(&llama_free)> ctx(
        llama_init_from_model(model, cp), llama_free
    );
    if (!ctx) return "Could not allocate an inference context.";

    std::unique_ptr<llama_sampler, decltype(&llama_sampler_free)> sampler(
        llama_sampler_chain_init(llama_sampler_chain_default_params()),
        llama_sampler_free
    );
    if (!sampler) return "Could not create the sampler.";
    auto *greedy = llama_sampler_init_greedy();
    if (!greedy) return "Could not create the greedy sampler.";
    llama_sampler_chain_add(sampler.get(), greedy);

    std::unique_ptr<llama_batch_ext, decltype(&llama_batch_ext_free)> batch(
        llama_batch_ext_init(ctx.get()), llama_batch_ext_free
    );
    if (!batch) return "Could not create the input batch.";

    auto fill = [&](const llama_token *ids, int n, llama_pos start) {
        llama_batch_ext_clear(batch.get());
        for (int i = 0; i < n; ++i) {
            const int idx = llama_batch_ext_add_token(batch.get(), 0, ids[i]);
            if (idx < 0) return false;
            const llama_pos pos = start + i;
            llama_batch_ext_set_pos(batch.get(), idx, &pos);
        }
        llama_batch_ext_set_output_logits(batch.get(), n - 1, true);
        return true;
    };

    if (!fill(tokens.data(), count, 0)) return "Could not build prompt batch.";

    llama_pos next_pos = count;
    for (int i = 0; i < max_output; ++i) {
        if (llama_process(ctx.get(), LLAMA_PROCESS_TYPE_DECODE, batch.get()) != 0)
            return "Model loaded, but decoding failed.";

        const llama_token token = llama_sampler_sample(sampler.get(), ctx.get(), -1);
        if (llama_vocab_is_eog(vocab, token)) break;

        char piece[256];
        const int n = llama_token_to_piece(vocab, token, piece, sizeof(piece), 0, false);
        if (n < 0) return "Generated token did not fit the text buffer.";
        reply.append(piece, n);

        if (i + 1 < max_output && !fill(&token, 1, next_pos++))
            return "Could not build the next token batch.";
    }

    return reply.empty() ? "Model stopped without generating text." : nullptr;
}