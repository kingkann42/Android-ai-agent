#include <jni.h>
#include <cstdio>
#include <mutex>
#include <string>
#include "llama.h"
#include "offline_reply.h"

namespace {
    std::mutex logMutex;
    std::string loaderMessages;

    void captureLog(enum ggml_log_level level, const char *text, void *) {
        if (!text || level == GGML_LOG_LEVEL_DEBUG) return;

        std::lock_guard<std::mutex> lock(logMutex);
        // Keep a short tail so a useful error isn't lost behind model metadata.
        loaderMessages.append(text);
        if (loaderMessages.size() > 2000) {
            loaderMessages.erase(0, loaderMessages.size() - 2000);
        }
    }

    void reportFailure(JNIEnv *env, std::string message) {
        // ThrowNew expects modified UTF-8. Keep diagnostic text ASCII-safe.
        for (char &c : message) {
            unsigned char ch = static_cast<unsigned char>(c);
            if (ch != '\n' && (ch < 32 || ch > 126)) c = ' ';
        }
        jclass type = env->FindClass("java/lang/IllegalStateException");
        if (type) env->ThrowNew(type, message.c_str());
    }
}

extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_example_androidagent_LocalModelBridge_checkModel(
        JNIEnv *env, jobject, jstring modelPath, jboolean wantReply, jbyteArray questionBytes) {
        std::string question;
    if (wantReply == JNI_TRUE) {
        if (questionBytes == nullptr) {
            reportFailure(env, "No question supplied.");
            return nullptr;
        }
        const jsize size = env->GetArrayLength(questionBytes);
        if (size < 1 || size > 2048) {
            reportFailure(env, "Enter a short question.");
            return nullptr;
        }
        question.resize(size);
        env->GetByteArrayRegion(
            questionBytes, 0, size, reinterpret_cast<jbyte *>(&question[0])
        );
        if (env->ExceptionCheck()) return nullptr;
    }
    {
        std::lock_guard<std::mutex> lock(logMutex);
        loaderMessages.clear();
    }

    static std::once_flag initialized;
    std::call_once(initialized, [] {
        llama_log_set(captureLog, nullptr);
        llama_backend_init();
    });

    auto params = llama_model_default_params();
    params.n_gpu_layers = 0;

    const char *path = env->GetStringUTFChars(modelPath, nullptr);
    if (path == nullptr) return nullptr;

    llama_model *model = llama_model_load_from_file(path, params);
    env->ReleaseStringUTFChars(modelPath, path);
    if (!model) {
        std::string detail;
        {
            std::lock_guard<std::mutex> lock(logMutex);
            detail = loaderMessages;
        }
        reportFailure(env, detail.empty()
            ? "llama.cpp returned no model and no diagnostic."
            : "llama.cpp loader:\n" + detail);
        return nullptr;
    }

    std::string reply;
    const char *error = nullptr;
    if (wantReply == JNI_TRUE) {
        error = generate_test_reply(model, question, reply);
    }
    llama_model_free(model);

    if (error) {
        reportFailure(env, error);
        return nullptr;
    }

    const jsize length = static_cast<jsize>(reply.size());
    jbyteArray result = env->NewByteArray(length);
    if (result && length > 0) {
        env->SetByteArrayRegion(
            result, 0, length,
            reinterpret_cast<const jbyte *>(reply.data())
        );
    }
    return result;
}