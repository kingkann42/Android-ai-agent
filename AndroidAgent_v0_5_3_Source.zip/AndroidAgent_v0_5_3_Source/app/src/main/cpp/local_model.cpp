#include <jni.h>
#include <cstdio>
#include <mutex>
#include "llama.h"

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_androidagent_LocalModelBridge_checkModel(
        JNIEnv *, jobject, jint fd) {
    if (fd < 0) return JNI_FALSE;

    static std::once_flag initialized;
    std::call_once(initialized, [] { llama_backend_init(); });

    // Kotlin keeps the selected file open until this function returns.
    char path[64];
    std::snprintf(path, sizeof(path), "/proc/self/fd/%d", static_cast<int>(fd));

    auto params = llama_model_default_params();
    params.n_gpu_layers = 0;
    params.use_mmap = true;
    params.use_mlock = false;

    llama_model * model = llama_model_load_from_file(path, params);
    if (model == nullptr) return JNI_FALSE;

    llama_model_free(model);
    return JNI_TRUE;
}