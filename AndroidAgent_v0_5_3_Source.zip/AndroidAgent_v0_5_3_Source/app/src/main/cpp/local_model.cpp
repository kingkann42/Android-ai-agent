#include <jni.h>
#include <cstdio>
#include <mutex>
#include <string>
#include "llama.h"

namespace {
    std::mutex logMutex;
    std::string loaderMessages;

    void captureLog(enum ggml_log_level level, const char *text, void *) {
        if (!text || level == GGML_LOG_LEVEL_DEBUG) return;

        std::lock_guard<std::mutex> lock(logMutex);
        // Keep a short tail so a useful error isn't lost behind model metadata.
        loaderMessages.append(text);
        if (loaderMessages.size() > 2000) {
            loaderMessages.erase(0, loaderMessages.size() - 2000);
        }
    }

    void reportFailure(JNIEnv *env, std::string message) {
        // ThrowNew expects modified UTF-8. Keep diagnostic text ASCII-safe.
        for (char &c : message) {
            unsigned char ch = static_cast<unsigned char>(c);
            if (ch != '\n' && (ch < 32 || ch > 126)) c = ' ';
        }
        jclass type = env->FindClass("java/lang/IllegalStateException");
        if (type) env->ThrowNew(type, message.c_str());
    }
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_androidagent_LocalModelBridge_checkModel(
        JNIEnv *env, jobject, jint fd) {
    if (fd < 0) {
        reportFailure(env, "Android supplied an invalid file descriptor.");
        return JNI_FALSE;
    }

    {
        std::lock_guard<std::mutex> lock(logMutex);
        loaderMessages.clear();
    }

    static std::once_flag initialized;
    std::call_once(initialized, [] {
        llama_log_set(captureLog, nullptr);
        llama_backend_init();
    });

    char path[64];
    std::snprintf(path, sizeof(path), "/proc/self/fd/%d", static_cast<int>(fd));

    auto params = llama_model_default_params();
    params.n_gpu_layers = 0;

    llama_model *model = llama_model_load_from_file(path, params);
    if (!model) {
        std::string detail;
        {
            std::lock_guard<std::mutex> lock(logMutex);
            detail = loaderMessages;
        }
        reportFailure(env, detail.empty()
            ? "llama.cpp returned no model and no diagnostic."
            : "llama.cpp loader:\n" + detail);
        return JNI_FALSE;
    }

    llama_model_free(model);
    return JNI_TRUE;
}