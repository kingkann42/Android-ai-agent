# Android Agent v0.5.2 — test prototype source

This is the next native Android/Kotlin prototype based on the latest Android AI Agent decisions and the v0.5 engineering blueprint. It is a source project, **not yet a compiled APK**.

## What changed in v0.5.2

- **Test connection** button (Edit connection): sends a read-only GET (`/api/models` or `/api/tags`) and shows the HTTP status, response headers and the start of the reply. Use it to see what is actually answering on the server URL.
- **Extra headers** field (optional, one `Name: value` per line, max 10) sent with plan requests and the test. For gateways that require extra headers.
- More accurate error messages: 401 (API key), 403 (gateway/server refused), TLS handshake rejected (use the MagicDNS hostname, not the IP) and untrusted certificate are now distinguished.
- If a gateway returns `403 {"error":"The request must come from this app."}`, that text is not from Open WebUI: ask the server's owner what the gateway requires.

## What changed in v0.5.1

- **Open WebUI support.** Strawberry Milk runs Open WebUI, not Ollama. New `OpenWebUiProvider` calls `POST /api/chat/completions` with a Bearer API key. It is the default; a switch in *Edit connection* selects the native Ollama provider instead.
- New defaults: server `https://100.91.123.85:8443`, model ID `qwen3.8:27b-q8_0`. If you saved settings in v0.5.0, open *Edit connection*, update them, and Save (old saved values override the defaults).
- API key field (stored unencrypted in app preferences; fine for this private test build, move to Keystore-backed storage later).
- Planner robustness: reasoning (`<think>`) blocks are stripped, the outermost JSON object is extracted, empty model replies fail with a clear message. Ollama requests now send `think:false` and `keep_alive`; read timeout raised to 5 minutes for first model load.
- Clearer error messages for 401/403, 404 and certificate failures (use *Show details* for the raw error).
- Networking: global cleartext permission removed. HTTPS only, except cleartext to the single tailnet address in `network_security_config.xml`.
- Accessibility service config: gesture capability and fuller window trees enabled (groundwork for later screen-reading tools). Behavior is unchanged: still opt-in, manual, allowlisted.
- Still **not compiled or device-tested** in the environment that produced this source.

## Certificates (HTTPS on port 8443)

Android rejects self-signed certificates. Options, best first:
1. Serve Open WebUI behind a certificate issued for the host's Tailscale name (`tailscale cert` / `tailscale serve`), then use that `https://<name>.<tailnet>.ts.net:8443` URL and add the hostname to `network_security_config.xml`.
2. Install the server's CA/certificate on the phone (Settings > Security > Encryption & credentials > Install a certificate > CA certificate). This build trusts user-installed CAs for `100.91.123.85` only.

Do not disable certificate verification.

## Included in v0.5.0

- Native Android launcher activity with typed instruction entry and push-to-talk speech input.
- Provider interface (`AiProvider`) with Open WebUI and Ollama implementations; server, model and API key settings are editable.
- Strawberry Milk connection using the previously supplied Tailscale address as an editable default: `https://100.91.123.85:8443` (Open WebUI).
- Default model ID: `qwen3.8:27b-q8_0`.
- Strict JSON plan parsing and local tool-schema allowlist. Model output is only a proposal.
- Explicit per-step Approve & run / Reject controls.
- SQLite task history and action audit log, including duplicate-step protection.
- Narrow launcher-app discovery (MAIN + LAUNCHER query only) and app launch.
- User-selected source file + destination folder using Android Storage Access Framework; copy is verified with byte count and SHA-256. Existing destination names are rejected; overwrite is not supported.
- Optional AccessibilityService, disabled until the user explicitly enables it in Android Settings. It does not log event text or run background taps. The user manually enters one allowed package and exact visible text, then taps the explicit action button.
- GitHub Actions workflow to build and upload a debug APK artifact.

## Important design boundaries

- No root, shell execution, SMS/calls, purchases, deletion, credential access, covert recording, or unrestricted app-data access.
- No third-party AI fallback. If Tailscale or Strawberry Milk is unavailable, planning fails visibly; local file selection and history remain usable.
- The app does not request `QUERY_ALL_PACKAGES`; Android only reveals apps matching the launcher intent query.
- SAF grants access only to the file/folder selected by the user. Android 11+ blocks some protected roots and app-data locations, including `Android/data` and `Android/obb`.
- Accessibility is an opt-in experimental bridge, not a guarantee that every app can be automated. Secure windows, app-specific protections, and Android restrictions remain in force.
- This prototype sends the instruction text to the configured model server. Do not send passwords, authentication codes, or other secrets.
- Keep the Open WebUI endpoint reachable only over Tailscale, apply Tailscale ACLs/firewall rules, and never expose port 8443 to the public internet. Treat the API key as a secret.
- Local SQLite records are not encrypted in this prototype. Android backup is disabled.

## Project folder

The Gradle project folder is the folder containing `settings.gradle.kts` and
`app/`. In the v0.5.3 source ZIP, this is `AndroidAgent_v0.5.3/`.

## Build a debug APK with GitHub Actions

No local Android Studio installation is required. The **Build App** workflow
(`.github/workflows/build-app.yml`) locates the Gradle project automatically.
If the repository contains the source ZIP instead of extracted project files,
the workflow extracts it before building.

1. Open the repository’s **Actions** tab and select **Build App**.
2. Select **Run workflow**, choose `main`, and confirm. Manual runs require
   write access. A push to `main` also starts the workflow automatically.
3. After a successful run, open the run summary. Under **Artifacts**, download
   `AndroidAgent-v0.5.3-debug-apk` and extract it to get `app-debug.apk`.

The workflow runs `gradle --no-daemon assembleDebug`. It builds and uploads
the debug APK; it does not install it or test inference on a device.

## Build using GitHub Actions (no Android SDK needed on your computer)

1. Create a private GitHub repository.
2. Upload the contents of this project folder to the repository root (not the containing parent folder).
3. Open **Actions** and run **Build Android Agent APK** using **Run workflow**, or push to `main`.
4. When the workflow succeeds, open the run and download the artifact named `AndroidAgent-v0.5.1-debug-apk`.
5. Extract the artifact; it contains `app-debug.apk`. Transfer it to the phone and install it.

## First phone setup and test sequence

1. Install and sign in to Tailscale on the phone; confirm it is connected to the same tailnet as Strawberry Milk.
2. In Open WebUI create an API key (Settings > Account > API Keys). Confirm the exact model ID with `GET /api/models`; it should include `qwen3.8:27b-q8_0`.
3. From the phone's browser, confirm `https://100.91.123.85:8443` loads over the tailnet. Windows Firewall must permit the phone/tailnet on that port. Do not make a public router port-forward. See *Certificates* above if the browser warns about the certificate.
4. Open Android Agent > Edit connection. Confirm the server URL and model ID, leave the Open WebUI switch on, paste the API key, then Save.
5. Type a harmless request such as: `Create a task called Prototype smoke test with details Verify local task creation.` Tap **Create plan**. Confirm a proposal appears and nothing runs before approval. Tap **Approve & run**, then confirm the task appears in history.
6. Tap **Discover apps**, search for Calculator, and tap **Open**. Confirm it launches and the action appears in the audit log.
7. Create a small `Agent-Test.txt` file in a normal user folder. In the app choose it as the source, choose a different destination folder, keep or edit the destination filename, and tap **Copy and verify**. Confirm the SHA-256 result is reported and the destination file exists.
8. Test duplicate protection by attempting a second copy with the same destination filename. It should refuse to overwrite.
9. Test voice input using **Speak**. Android's installed speech-recognition provider must be available.
10. Only if you want to test UI automation, open Accessibility settings, enable **Android Agent task-scoped accessibility**, return to the app, set the exact target app package name, and test a harmless visible button using its exact label. Disable the service when finished if you do not need it.
11. Disconnect Tailscale and request a plan. The app should show a connection failure and must not silently switch AI providers.

## What is deliberately not claimed

The source has not been compiled or tested against the physical B1661V in this environment. The current build environment has Java but no Android SDK or Gradle installation, so an APK cannot honestly be supplied from this run. The GitHub Actions workflow and Android Studio steps above are provided to produce the first installable debug APK. The first physical-device test must verify Android 16 compatibility, speech provider behavior, file-provider behavior, Tailscale reachability, and Accessibility behavior on this exact firmware.

## Planned follow-on work after first device test

- Fix any build/device-specific defects found in the first APK.
- Expand task persistence into a durable multi-step task state machine with explicit recovery checkpoints.
- Add per-app official integrations before broadening Accessibility.
- Improve file browsing (nested folders, selected-folder bookmarks, read/preview, and user-confirmed copy workflows).
- Add a dedicated, authenticated host-side gateway before treating the Ollama endpoint as hardened.
- Evaluate any need for optional all-files access only after SAF tests show a specific justified gap.
- Root feasibility review remains last and only for a documented capability that cannot be achieved non-root.
