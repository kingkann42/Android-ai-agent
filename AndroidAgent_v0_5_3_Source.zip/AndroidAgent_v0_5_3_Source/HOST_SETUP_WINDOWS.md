# Strawberry Milk (Windows) — private Tailscale access to Open WebUI

The Android app's editable default is `https://100.91.123.85:8443`. The project context identifies `100.91.123.85` as Strawberry Milk's Tailscale IPv4 address. Verify it still matches Tailscale before using it.

## 1. Confirm Open WebUI and the model

In a browser on Strawberry Milk, open Open WebUI and confirm the model `qwen3.8:27b-q8_0` is available.

## 2. Create an API key

Open WebUI > Settings > Account > API Keys > create key. If the option is missing, an admin must enable API keys (Admin Settings > General). Keep the key secret.

## 3. Test the API from another tailnet device

```
curl -k https://100.91.123.85:8443/api/models -H "Authorization: Bearer YOUR_KEY"
curl -k https://100.91.123.85:8443/api/chat/completions -H "Authorization: Bearer YOUR_KEY" -H "Content-Type: application/json" -d "{\"model\":\"qwen3.8:27b-q8_0\",\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}]}"
```

`-k` skips certificate checks for this test only. A 401 means a wrong/missing key. If the port does not respond over HTTPS, try `http://` and adjust the app URL.

## 4. Restrict Windows Firewall to the tailnet (Administrator PowerShell)

```powershell
New-NetFirewallRule -DisplayName "Open WebUI from Tailscale only" -Direction Inbound -Action Allow -Protocol TCP -LocalAddress 100.91.123.85 -LocalPort 8443 -RemoteAddress 100.64.0.0/10 -Profile Any
```

Tighten `-RemoteAddress` to the phone's exact Tailscale IP and restrict with Tailscale ACLs. Do not create a router port-forward.

## 5. Certificate

Android rejects self-signed certificates. Prefer a Tailscale-issued certificate for the host's `.ts.net` name; otherwise install the certificate as a CA on the phone (see README, Certificates).

## 6. Phone

Connect to the same tailnet, open Android Agent > Edit connection, enter URL, model ID and API key, Save, then Preview plan.
